-- TASK 2: Creazione DB e Tabelle

create database ToysGroup;
use ToysGroup;

-- Regione e RegioneStati
create table RegioneStati (
ID_RegioneStati int
, Regione_Stati varchar(50)
, constraint PK_RegioneStati primary key (ID_RegioneStati)
);
create table Regione (
ID_Regione int
, Città varchar(50)
, Regione varchar(50)
, Stato varchar(50)
, ID_RegioneStati int
, constraint PK_Regione primary key (ID_Regione)
, constraint FK_RegioneStati_Regione foreign key (ID_RegioneStati) references RegioneStati (ID_RegioneStati)
);

-- Prodotto e Categoria
create table Categoria (
ID_Categoria int
, Categoria varchar(50)
, constraint PK_Categoria primary key (ID_Categoria)
);
create table Prodotto (
ID_Prodotto int
, Prodotto varchar(50)
, Costo decimal(10,2)
, ID_Categoria int
, constraint PK_Prodotto primary key (ID_Prodotto)
, constraint FK_Categoria_Prodotto foreign key (ID_Categoria) references Categoria (ID_Categoria)
);

-- Reseller
create table Reseller (
ID_Reseller int
, Nome_Reseller varchar(50)
, ID_Regione int
, constraint PK_Reseller primary key (ID_Reseller)
, constraint FK_Regione_Reseller foreign key (ID_Regione) references Regione (ID_Regione)
);

-- Ordini
create table Ordini (
ID_Ordine varchar(50)
, Data_Ordine date
, Quantità int
, Importo decimal (10,2)
, ID_Prodotto int
, ID_Reseller int
, ID_Regione int
, constraint PK_Ordini primary key(ID_Ordine)
, constraint FK_Prodotto_Ordini foreign key (ID_Prodotto) references Prodotto (ID_Prodotto)
, constraint FK_Reseller_Ordini foreign key (ID_Reseller) references Reseller (ID_Reseller)
, constraint FK_Regione_Ordini foreign key (ID_Regione) references Regione (ID_Regione)
);

-- TASK 3: Popolamento Tabelle
insert into RegioneStati values
(1, 'Europa')
, (2, 'America')
, (3, 'Asia')
, (4, 'Oceania');

insert into Regione values
(1, 'Parigi', 'Île-de-France', 'Francia', 1)
, (2, 'Berlino', 'Brandeburgo', 'Germania', 1)
, (3, 'Madrid', 'Comunidad de Madrid', 'Spagna', 1)
, (4, 'Roma', 'Lazio', 'Italia', 1)
, (5, 'New York', 'New York', 'Stati Uniti', 2)
, (6, 'Los Angeles', 'California', 'Stati Uniti', 2)
, (7, 'Toronto', 'Ontario', 'Canada', 2)
, (8, 'Città del Messico', 'Distretto Federale', 'Messico', 2)
, (9, 'Tokyo', 'Kantō', 'Giappone', 3)
, (10, 'Seoul', 'Seoul Capital Area', 'Corea del Sud', 3)
, (11, 'Bangkok', 'Bangkok', 'Thailandia', 3)
, (12, 'Shanghai', 'Shanghai', 'Cina', 3)
, (13, 'Sydney', 'Nuovo Galles del Sud', 'Australia', 4)
, (14, 'Auckland', 'Auckland', 'Nuova Zelanda', 4)
, (15, 'Melbourne', 'Victoria', 'Australia', 4);

insert into Categoria values
(1, 'Giocattoli Bambino')
, (2, 'Giocattoli Bambina')
, (3, 'Bambole')
, (4, 'Macchina Radiocomandata');

insert into Prodotto values
(1, 'Set costruzioni Lego', 39.99, 1)
, (2, 'Pista Hot Wheels', 29.90, 1)
, (3, 'Trenino elettrico', 49.99, 1)
, (4, 'Tappeto puzzle', 19.50, 1)
, (5, 'Set da tè giocattolo', 14.99, 2)
, (6, 'Casa delle bambole', 59.90, 2)
, (7, 'Peluche unicorno', 17.99, 2)
, (8, 'Kit makeup giocattolo', 12.50, 2)
, (9, 'Bambola classica', 22.90, 3)
, (10, 'Bambola con vestiti intercambiabili', 27.50, 3)
, (11, 'Bambola parlante', 34.90, 3)
, (12, 'Bambola neonata con accessori', 44.99, 3)
, (13, 'Macchina RC fuoristrada', 69.90, 4)
, (14, 'Macchina RC sportiva', 59.99, 4)
, (15, 'Macchina RC 4x4', 74.50, 4)
, (16, 'Camion RC con luci', 64.90, 4)
, (17, 'Mini drone giocattolo', 49.00, 4)
, (18, 'Bambola fashion con accessori', 29.90, 3)
, (19, 'Macchina RC da drift', 67.90, 4)
, (20, 'Set trenino e pista bambino', 32.50, 1);

insert into Reseller values
(1, 'GiocoMania', 1)
,(2, 'Toys World', 2)
, (3, 'Bimbi&Giocattoli', 3)
, (4, 'HappyToys', 4)
, (5, 'PlayPlanet', 5)
, (6, 'Bambini Felici', 6)
, (7, 'Regalo Perfetto', 7)
, (8, 'ToyStation', 8)
, (9, 'Giocheria Plus', 9)
, (10, 'MiniMarket Toys', 10)
, (11, 'L’Isola dei Giochi', 11)
, (12, 'DreamToys', 12)
, (13, 'GiochiMania Kids', 13)
, (14, 'Infanzia Store', 14)
, (15, 'Magic Toys', 15)
, (16, 'BabyGames', 1)
, (17, 'ToyMax', 2)
, (18, 'GiocoBoom', 3)
, (19, 'Smile Toys', 4)
, (20, 'Toy Express', 5)
, (21, 'ColorLand', 6)
, (22, 'Mondo Baby', 7)
, (23, 'SuperGiochi', 8)
, (24, 'ToyCity', 9)
, (25, 'JoyGames', 10);

insert into Ordini values
('SORDN01', '2024-01-10', 3, 119.97, 1, 1, 1)
, ('SORDN02', '2024-01-22', 2, 59.80, 2, 2, 2)
, ('SORDN03', '2024-02-14', 1, 49.99, 3, 3, 3)
, ('SORDN04', '2024-03-01', 5, 97.50, 5, 4, 4)
, ('SORDN05', '2024-03-19', 2, 119.80, 6, 5, 5)
, ('SORDN06', '2024-04-05', 1, 17.99, 7, 6, 6)
, ('SORDN07', '2024-04-28', 4, 91.60, 9, 7, 7)
, ('SORDN08', '2024-05-11', 3, 82.50, 10, 8, 8)
, ('SORDN09', '2024-05-30', 2, 69.80, 11, 9, 9)
, ('SORDN10', '2024-06-15', 1, 44.99, 12, 10, 10)
, ('SORDN11', '2024-07-04', 3, 209.70, 13, 11, 11)
, ('SORDN12', '2024-07-21', 2, 119.98, 14, 12, 12)
, ('SORDN13', '2024-08-02', 2, 149.00, 15, 13, 13)
, ('SORDN14', '2024-08-19', 1, 349.00, 16, 14, 14)
, ('SORDN15', '2024-09-05', 4, 51.60, 17, 15, 15)
, ('SORDN16', '2024-10-01', 3, 73.50, 19, 16, 1)
, ('SORDN17', '2024-11-12', 1, 32.50, 20, 17, 2)
, ('SORDN18', '2024-12-07', 2, 79.98, 1, 18, 3)
, ('SORDN19', '2024-12-21', 3, 89.70, 2, 19, 4)
, ('SORDN20', '2024-12-31', 2, 99.98, 3, 20, 5)
, ('SORDN21', '2025-01-02', 1, 14.99, 5, 21, 6)
, ('SORDN22', '2025-01-08', 2, 119.80, 6, 22, 7)
, ('SORDN23', '2025-01-14', 3, 53.97, 7, 23, 8)
, ('SORDN24', '2025-01-19', 1, 22.90, 9, 24, 9)
, ('SORDN25', '2025-01-25', 2, 55.00, 10, 25, 10)
, ('SORDN26', '2025-02-01', 3, 104.70, 11, 1, 11)
, ('SORDN27', '2025-02-12', 1, 14.99, 5, 21, 6)
, ('SORDN28', '2025-02-18', 2, 139.80, 13, 3, 13)
, ('SORDN29', '2025-02-25', 3, 179.97, 14, 4, 14)
, ('SORDN30', '2025-03-01', 1, 74.50, 15, 5, 15)
, ('SORDN31', '2025-03-04', 2, 698.00, 16, 6, 1)
, ('SORDN32', '2025-03-07', 1, 49.00, 17, 7, 2)
, ('SORDN33', '2025-03-10', 2, 135.80, 19, 8, 3)
, ('SORDN34', '2025-03-12', 1, 32.50, 20, 9, 4)
, ('SORDN35', '2025-03-15', 4, 159.96, 1, 10, 5)
, ('SORDN36', '2025-03-18', 2, 59.80, 2, 11, 6)
, ('SORDN37', '2025-03-22', 3, 149.97, 3, 12, 7)
, ('SORDN38', '2025-03-25', 1, 14.99, 5, 13, 8)
, ('SORDN39', '2025-03-28', 5, 14.99, 16, 13, 8)
, ('SORDN40', '2025-04-01', 1, 17.99, 7, 15, 10)
, ('SORDN41', '2025-04-02', 2, 45.80, 9, 16, 11)
, ('SORDN42', '2025-04-03', 3, 82.50, 10, 17, 12)
, ('SORDN43', '2025-04-04', 2, 69.80, 11, 18, 13)
, ('SORDN44', '2025-04-05', 1, 44.99, 12, 19, 14)
, ('SORDN45', '2025-04-06', 3, 179.97, 14, 19, 4)
, ('SORDN46', '2025-04-07', 3, 179.97, 14, 21, 1)
, ('SORDN47', '2025-04-08', 2, 149.00, 15, 22, 2)
, ('SORDN48', '2025-04-09', 1, 349.00, 16, 23, 3)
, ('SORDN49', '2025-04-10', 3, 147.00, 17, 24, 4)
, ('SORDN50', '2025-04-10', 2, 135.80, 19, 25, 5);