-- TASK 4 PUNTO 1
-- Verifica PK RegioneStati
select ID_RegioneStati
, COUNT(ID_RegioneStati) AS ConteggioPK
from RegioneStati
group by ID_RegioneStati
having COUNT(ID_RegioneStati)> 1;
-- Verifica PK Regione
select ID_Regione
, COUNT(ID_Regione) AS ConteggioPK
from Regione
group by ID_Regione
having COUNT(ID_Regione)> 1;
-- Verifica PK Categoria
select ID_Categoria
, COUNT(ID_Categoria) AS ConteggioPK
from Categoria
group by ID_Categoria
having COUNT(ID_Categoria)> 1;
-- Verifica PK Prodotto
select ID_Prodotto
, COUNT(ID_Prodotto) AS ConteggioPK
from Prodotto
group by ID_Prodotto
having COUNT(ID_Prodotto)> 1;
-- Verifica PK Reseller
select ID_Reseller
, COUNT(ID_Reseller) AS ConteggioPK
from Reseller
group by ID_Reseller
having COUNT(ID_Reseller)> 1;
-- Verifica PK Ordini
select ID_Ordine
, COUNT(ID_Ordine) AS ConteggioPK
from Ordini
group by ID_Ordine
having COUNT(ID_Ordine)> 1;
/*Per verficare che ogni ID definito PK nelle varie tabelle sia univoco ho usato un COUNT sui vari campi
e un having COUNT >1 cosi da estrarre i valori maggiori di 1 e quindi non univoci.In tutte le tabelle
la visualizzazione non da risultati e quindi ho la conferma dell'univocità*/

-- TASK 4 PUNTO 2
select O.ID_Ordine as Codice_Documento
, O.Data_Ordine as Data_Ordine
, P.Prodotto as Nome_Prodotto
, C.Categoria as Categoria
, R.Nome_Reseller as Nome_Reseller
, RG.Città as Città
, RG.Stato as Stato
, RGS.Regione_Stati as Regione_Vendita
, case when datediff(curdate(), O.Data_Ordine) > 180 THEN True
else False end as Verifica_Data_Booleano
from ordini as O
inner join prodotto as P
on O.ID_Prodotto = P.ID_Prodotto
inner join categoria as C
on P.ID_Categoria = C.ID_Categoria
inner join reseller as R
on O.ID_Reseller = R.ID_Reseller
inner join regione as RG
on O.ID_Regione = RG.ID_Regione
inner join regionestati as RGS
on RG.ID_RegioneStati = RGS.ID_RegioneStati;

-- TASK 4 PUNTO 3
select Or25.ID_Prodotto as Codice_Prodotto               
, sum(Or25.Quantità) as Quantità_Venduta2025
from ordini as Or25
where year (Or25.Data_Ordine) = 2025
group by Or25.ID_Prodotto
having sum(Or25.Quantità) > (
select  avg (Quantità_Venduta2025)
from (
select sum(Quantità) as Quantità_Venduta2025
from ordini
where year (Data_Ordine) = 2025
group by ID_Prodotto) as Media_Vendite2025);

-- TASK 4 PUNTO 4
select P.ID_Prodotto  as Codice_Prodotto
, year (O.Data_Ordine) as Anno_Fatturato
, sum(O.Importo) as Fatturato
from prodotto as P
inner join ordini as O
on P.ID_Prodotto = O.ID_Prodotto
group by P.ID_Prodotto, year (O.Data_Ordine)
order by P.ID_Prodotto asc;

-- TASK 4 PUNTO 5
select RG.Stato as Stato
, year (O.Data_Ordine) as Anno
, sum(O.Importo) as Fatturato
from ordini as O
inner join regione as RG
on O.ID_Regione = RG.ID_Regione
group by RG.Stato , year(O.Data_Ordine)
order by year (O.Data_Ordine) desc, sum(O.Importo) desc;

-- TASK 4 PUNTO 6
select C.Categoria as Categoria_Prodotto
,count(C.Categoria) as Conteggio_Venduto
from ordini as O
inner join prodotto as P
on O.ID_Prodotto = P.ID_Prodotto
inner join categoria as C
on P.ID_Categoria = C.ID_Categoria
group by C.Categoria
order by count(C.Categoria) desc;
/*Usando il conteggio sulla Categoria dopo aver fatto un inner join con gli ordini si evince che la categoria
più richiesta sul mercato sia quella delle Macchina Radiocomandata*/
-- TASK 4 PUNTO 7
-- Approccio 1: SubQuery
select ID_Prodotto as Codice_Prodotto
, Prodotto as Nome_Prodotto
from prodotto
where ID_Prodotto not in (
select ID_Prodotto
from ordini);
-- Approccio 2: Left Join
select P.ID_Prodotto as Codice_Prodotto
, P.Prodotto as Nome_Prodotto
from prodotto as P
left join ordini as O
on P.ID_Prodotto = O.ID_Prodotto
where O.ID_Prodotto is null;
/*Usando 2 approcci diversi(uno con SubQuery e l'altro con Left Join) si evince, in entrambi i casi,
che i prodotti non venduti sono quelli che hanno come ID_Prodotto 4, 8, 18.*/

-- TASK 4 PUNTO 8
create view View_ProdottoCategoria as (
select P.ID_Prodotto as Codice_Prodotto
, P.Prodotto as Nome_Prodotto
, C.ID_Categoria as Codice_Categoria
, C.Categoria as Nome_Categoria
from prodotto as P
inner join categoria as C
on P.ID_Categoria = C.ID_Categoria
order by P.ID_Prodotto asc);
select *
from View_ProdottoCategoria;

-- TASK 4 PUNTO 9
/*Creare una vista per le informazioni geografiche*/
create view View_GeograficaRegioni as (
select RG.ID_Regione as Codice_Regione
, RG.Città as Città
, RG.Regione as Regione
, RG.Stato as Stato
, RGS.Regione_Stati as Continente
from regione as RG
inner join regionestati as RGS
on RG.ID_RegioneStati = RGS.ID_RegioneStati
order by RG.ID_Regione asc);
select *
from View_GeograficaRegioni;
/*Vista Reseller + Informazioni Geografiche (la aggiungo di mia iniziativa solo per non sprecare il tempo impiegato per
creare la Tabella Reseller e annessi Record*/
create view View_GeograficaResellerRegioni as (
select R.ID_Reseller as Codice_Reseller
, R.Nome_Reseller as Nome_Reseller
, R.ID_Regione as Codice_Regione
, RG.Città as Città
, RG.Regione as Regione
, RG.Stato as Stato
, RGS.Regione_Stati as Continente
from regione as RG
inner join reseller as R
on RG.ID_Regione = R.ID_Regione
inner join regionestati as RGS
on RG.ID_RegioneStati = RGS.ID_RegioneStati
order by R.ID_Reseller asc);
select *
from View_GeograficaResellerRegioni;